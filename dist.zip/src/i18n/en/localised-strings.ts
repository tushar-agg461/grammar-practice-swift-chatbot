export const localisedStrings = {
  welcomeMessage: 'Hello, Welcome to English Grammar Practice!!',
  seeMoreMessage: 'See More Data',
  language_hindi: 'हिन्दी',
  language_english: 'English',
  language_changed: 'Language changed to English',
};
