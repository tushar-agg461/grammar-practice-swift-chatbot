export const localisedStrings = {
  welcomeMessage: `नमस्कार 👋 Khabri Media Bot में आपका स्वागत है! 🤖 हमारे पास दुनिया भर से समाचार 🌍, आपके क्षेत्र से समाचार 🏡`,
  language_changed: 'भाषा बदलकर हिंदी हो गई',
};
